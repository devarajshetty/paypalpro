<!DOCTYPE html>
<html>
<body>

<form method="post" action="http://192.168.1.30/devaraj/paypalpro/paypalpro.php">
    First Name: <input type="text" name="fname" value="Devaraj" readonly="readonly"><br/>
    Last Name: <input type="text" name="Lname" value="Palanisamy" readonly="readonly"><br/>
    Street: <input type="text" name="Street" value="South Street"><br/>
    City: <input type="text" name="City" value="Las Vegas" readonly="readonly"><br/>
    State: <input type="text" name="State" value="Nevada" readonly="readonly"><br/>
    Country Code: <input type="text" name="Country_code" value="Us" readonly="readonly"><br/>
    Zip Code: <input type="text" name="Zip_code" value="123456" readonly="readonly"> <br/>
    Amount: <input type="text" name="Amount" value="100.00" readonly="readonly"><br/>
       Currency Code: <input type="text" name="Currency_no" value="USD" readonly="readonly"><br/>
       Account No: <input type="text" name="Account_no" value="5522340006063638" readonly="readonly"><br/>
       Exp Date: <input type="number" name="Exp_date" value="022013" readonly="readonly"><br/>
       Cvv: <input type="number" name="Cvv" value="464" readonly="readonly"><br/>
       Cardtype:<input type="text" name="Cardtype" value="Visa" readonly="readonly"><br/>
       <input type="submit" name="submit">
</form>



</body>
</html>